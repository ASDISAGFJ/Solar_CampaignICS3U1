import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Bullet extends Rectangle {

    private long creationTime;

    private static final double BULLET_SPEED = 5;
    private static final double KNOCKBACK_FACTOR = 2.0;

    public Bullet(double startX, double startY, Color color, long creationTime) {
        super(20, 10, color);
        setTranslateX(startX + 10);
        setTranslateY(startY + 20); // Adjust the starting position based on the player's height
        this.creationTime = creationTime;
    }

    public void move(double amount) {
        setTranslateX(getTranslateX() + BULLET_SPEED * amount);
    }




}
